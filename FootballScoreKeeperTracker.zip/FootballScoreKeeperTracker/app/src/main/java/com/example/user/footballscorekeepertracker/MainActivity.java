package com.example.user.footballscorekeepertracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * This activity keeps track of the football score for 2 teams.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // Tracks the score for Black flies
    int scoreBlackflies = 0;

    // Tracks the score for Blazers
    int scoreBlazers = 0;

    /**
     * Increase the score for Black flies by 6 points (touchdown).
     */
    public void addSixForBlackflies(View v) {
        scoreBlackflies = scoreBlackflies + 6;
        displayForBlackflies(scoreBlackflies);
    }
    /**
     * Increase the score for Black flies by 1 point (extra-point).
     */
    public void addOneForBlackflies(View v) {
        scoreBlackflies = scoreBlackflies + 1;
        displayForBlackflies(scoreBlackflies);
    }

    /**
     * Increase the score for Black flies by 2 points (2-point convert).
     */
    public void add2ForBlackflies(View v) {
        scoreBlackflies = scoreBlackflies + 2;
        displayForBlackflies(scoreBlackflies);
    }

    /**
     * Increase the score for Black flies by 3 points (field goal).
     */
    public void addThreeForBlackflies(View v) {
        scoreBlackflies = scoreBlackflies + 3;
        displayForBlackflies(scoreBlackflies);
    }

    /**
     * Increase the score for Black flies by 2 points (safety).
     */
    public void addTwoForBlackflies(View v) {
        scoreBlackflies = scoreBlackflies + 2;
        displayForBlackflies(scoreBlackflies);
    }


    /**
     * Increase the score for Blazers by 6 points (touchdown).
     */
    public void addSixForBlazers(View v) {
        scoreBlazers = scoreBlazers + 6;
        displayForBlazers(scoreBlazers);
    }
    /**
     * Increase the score for Blazers by 1 point (extra-point).
     */
    public void addOneForBlazers(View v) {
        scoreBlazers= scoreBlazers + 1;
        displayForBlazers(scoreBlazers);
    }

    /**
     * Increase the score for Blazers by 2 points (2-point convert).
     */
    public void add2ForBlazers(View v) {
        scoreBlazers = scoreBlazers + 2;
        displayForBlazers(scoreBlazers);
    }

    /**
     * Increase the score for Blazers by 3 points (field goal).
     */
    public void addThreeForBlazers(View v) {
        scoreBlazers = scoreBlazers + 3;
        displayForBlazers(scoreBlazers);
    }

    /**
     * Increase the score for Blazers by 2 points (safety).
     */
    public void addTwoForBlazers(View v) {
        scoreBlazers = scoreBlazers + 12;
        displayForBlazers(scoreBlazers);
    }

    /**
     * Resets the score for both teams to 0 points.
     */

    public void resetScore(View V) {
        scoreBlackflies = 0;
        scoreBlazers = 0;
        displayForBlackflies(scoreBlackflies);
        displayForBlazers(scoreBlazers);
    }



    /**
     * Displays the given score for Black flies.
     */
    public void displayForBlackflies(int score) {
        TextView scoreView = (TextView) findViewById(R.id.black_flies_score);
        scoreView.setText(String.valueOf(score));
    }


    /**
     * Displays the given score for Blazers.
     */
    public void displayForBlazers(int score) {
        TextView scoreView = (TextView) findViewById(R.id.blazers_score);
        scoreView.setText(String.valueOf(score));
    }


}
